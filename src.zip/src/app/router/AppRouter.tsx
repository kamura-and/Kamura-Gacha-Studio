import { createBrowserRouter } from "react-router-dom";

import { DashboardPage } from "@/features/dashboard/DashboardPage";
import { GachaPage } from "@/features/gacha/pages/GachaPage";
import { AppLayout } from "@/app/layout/AppLayout";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <AppLayout />,
    children: [
      {
        index: true,
        element: <DashboardPage />,
      },
      {
        path: "gacha",
        element: <GachaPage />,
      },
    ],
  },
]);